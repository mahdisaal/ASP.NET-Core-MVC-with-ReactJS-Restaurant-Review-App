﻿import Reviews from './Reviews.jsx';
ReactDOM.render(<Reviews />, document.getElementById('content'));